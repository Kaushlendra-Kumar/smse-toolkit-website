from django.apps import AppConfig


class SteelCompositionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Steel_Compositions'
