from mp_api.client import MPRester

with MPRester("AbDJYg7k48wD9VTldHPzzr9BgIMjSflN") as mpr:
    #do stuff with mpr...
    l = list(mpr.summary.available_fields)
    for i in l:
        print(i)